#### This team library is not only a collection of C++ codes, but also a diary of our
#### many sleepless nights, a silent witness of our excitements and stuggles, a loyal
#### companion in our difficult fights and a homage to all those who helped us learn.


# Contributors: 
* Hasin Rayhan Dewan Dhruboo
* Saad Muhammed Junayed
* Anik Sarker

### 1st Runners-up : ACM ICPC Dhaka Regional Onsite 2019 (BUET Gifted Hypocrites)
### Champion : ACM ICPC Dhaka Regional Online Preliminary 2018 (BUET Upside_Down)
