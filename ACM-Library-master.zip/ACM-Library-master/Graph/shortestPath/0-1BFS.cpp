/*
if edge weight is 1, insert at the end
otherwise insert at the beginning
*/
