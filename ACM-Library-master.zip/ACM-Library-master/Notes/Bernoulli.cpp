// Bernoulli Number : We have - 
// B(k) = sum over m in [0,k]  (-1)^m * m! / (m+1) * Str2(k,m)
